VENUS SILVER CENTER WEBSITE

Files:
- index.html
- styles.css
- script.js

How to edit:
1. Open index.html in any code editor.
2. Business text, phone, address, service links, hours, gallery image URLs and map are all editable in index.html.
3. Colors, typography, spacing and responsive styling are in styles.css.
4. Navigation and scroll-reveal behavior are in script.js.

Current business details used:
Venus Silver Center
Shop 2, Shaukat Plaza, Block 8 School Rd, F-6 Markaz, Islamabad 44000
Phone / WhatsApp: +92 334 5529044
Categories used: Jeweler, Jewelry Engraver, Jewelry Repair Service, Jewelry Store

Notes:
- Gallery/hero photographs are external editorial imagery loaded from Unsplash and are not presented as actual store inventory.
- Google Maps is embedded using the listing coordinates.
- WhatsApp messages are pre-filled and service-specific.
